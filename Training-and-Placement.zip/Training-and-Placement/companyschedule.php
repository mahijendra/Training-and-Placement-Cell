
 <?php 
 
	include("functions.php");
 
 ?>
 <?php

	$id=$_GET['userid'];
	$query="SELECT * FROM company WHERE `cid`=".$id;
	$result = mysqli_query($link,$query);
	$row = mysqli_fetch_assoc($result);
	$query1="SELECT * FROM companyschedule WHERE schcname='".$row['cname']."' LIMIT 1";
	$result1 = mysqli_query($link,$query1);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Training and Placement Portal</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <style>
    #detailstext {
	
		text-align:center;
		font-size:21px;
		color:black;
		font-weight:bold;
		font-style:Trebuchet MS, Helvetica, sans-serif;
		line-height:0.5px;
	
	}
	
	#newdetailstext {
		
		text-align:center;
		font-size:20px;
		font-weight:bold;
		font-style:Trebuchet MS, Helvetica, sans-serif;
		line-height:0.5px;
	}
  
  </style>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php">Training and Placement Portal</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background-image: url('images/muj.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start" data-scrollax-parent="true">
          <div class="col-md-8 ftco-animate text-center text-md-left mb-5" data-scrollax=" properties: { translateY: '70%' }">
          	<p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-3"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Company's Schedule</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Company's Schedule</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section bg-light">
      <div class="container">
	  <?php if($result1) {
			$row = mysqli_fetch_assoc($result1); ?>
        <div class="row justify-content-center mb-4 pb-1">
		<div class="well" style="border-style:groove;padding:65px;border-radius:12px;">
			<h1 style="font-weight:bold;font-family:Comic Sans MS,cursive, sans-serif;width:1050px;text-decoration:underline;text-align:center;">COMPANY'S SCHEDULE</h1><br>
			<span class="text" id="detailstext">Name - </span><span class="text" id="newdetailstext"><?php echo $row['schcname'] ?></span><br><hr>
			<span class="text" id="detailstext">Date - </span><span class="text" id="newdetailstext"><?php echo $row['schdate'] ?></span><br><hr>
			<span class="text" id="detailstext">Interview Timings - </span><span class="text" id="newdetailstext"><?php echo $row['schinterview'] ?></span><br><hr>
			<span class="text" id="detailstext">Backlog Allowed? - </span><span class="text" id="newdetailstext"><?php echo $row['schbacklog'] ?></span><br><hr>
			<span class="text" id="detailstext">Minimum Percentage Required - </span><span class="text" id="newdetailstext"><?php echo $row['schminper'] ?></span><br><hr>
			<span class="text" id="detailstext">Placement Type - </span><span class="text" id="newdetailstext"><?php echo $row['schplacement'] ?></span><br><hr>
			<span class="text" id="detailstext">Eligible Programs - </span><span class="text" id="newdetailstext"><?php echo $row['schprogram'] ?></span><br>
			<br>
	  <?php } else {
	  echo "<p class='alert alert-danger'>No Records to display yet.</p>";}
		  ?>
			
		</div>
        </div>
      </div>
    </section>

	
		
		<footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-6">
        	<div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About the Academic Programs</h2>
              <p>Faculty of Engineering<br>Faculty of Management and Commerce<br>Faculty of Design<br>Faculty of Science<br>Faculty of Arts and Law</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4" align="right">
            	<h2 class="ftco-heading-2">Quick Contacts</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="text">Manipal University Jaipur, Rajasthan 303007</span<span class="icon icon-map-marker"></span></li>
	                <li><span class="text">+2 392 3929 210</span><span class="icon icon-phone"></span></li>
	                <li><span class="text">placement@muj.edu.in</span><span class="icon icon-envelope"></span></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>

  

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>

  
  </body>
</html>.