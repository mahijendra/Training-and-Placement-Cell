 <?php include("functions.php"); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Training and Placement Portal</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">
	
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
	
    <link rel="stylesheet" href="css/style.css">
	

  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php">Training and Placement Portal</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	       <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item "><a href="index.php" class="nav-link">Home</a></li>
	          <li class="nav-item active"><a href="procedure.php" class="nav-link">Procedure</a></li>
			  <?php if(isset($_SESSION['sid']) or isset($_SESSION['cid']) or isset($_SESSION['aid'])) { ?>
				<li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
				<li class="nav-item"><a href="?function=logout" class="nav-link btn-outline-danger" style="border-radius:15px;" >Logout</a></li>
			  <?php } else { ?>
				<li class="nav-item"><a href="login.php" class="nav-link">Login</a></li>
				<li class="nav-item"><a class="nav-link" href="#" onclick="document.getElementById('adminlogin').style.display='block'">Admin Login</a></li>
			  <?php } ?>
			  

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
	
    <div class="hero-wrap js-fullheight" style="background-image: url('images/muj.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start" data-scrollax-parent="true">
          <div class="col-md-8 ftco-animate text-center text-md-left mb-5" data-scrollax=" properties: { translateY: '70%' }">
          	<p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-3"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Procedure</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Procedure</h1>
          </div>
        </div>
      </div>
    </div>
	
	
	<section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-4 pb-1">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <h2>Procedure</h2>
          </div>
        </div>
		<h6 style="color:black;"><strong>Campus Placement Procedure for Participating Organization/Industries</strong></h6><br>
		<ul>
		<li>The Training and  Placement Cell invites prospective organisations/industries in the months of June to August of every Academic Calendar, along with all relevant information to participate in the campus recruitment at the University. The organisations, in turn, can also contact the University T&P Officer for their requirement.</li>
		<li>The details of the respective final year students opting for placement well be sent to the company/organization concerned, as per their requirement, along with a tentative, mutually convenient date for the campus interviews.</li>
		<li>The company/organization may confirm the date or discuss a mutually convenient date, with the Coordinator-Training and Placement. The organisations will have an option to go for the campus recruitment to the Constituent Colleges / Institutions/ Schools / Departments of the University.</li>
		<li>After confirmation by the organisations, a pre-placement talk (PPT), will be arranged on the date. The company will conduct tests and/or group discussions to short list the interested students. If required, telephonic interviews or interviews through video conferencing can be arranged.</li>
		<li>The organisation will then interview the short listed students for final selection and will announce the results as soon as possible (preferably on the same day), once the selection process is over. Companies announcing results immediately after interviews will be preferred by the University and the students for early campus interview dates during the next academic year.</li>
		<li><strong>Note : </strong>The organisation that is unable to finalize the results on the same day and wish to have one more rounds of interviews at their office may do so within a weeks time.</li>
		</ul>
		<br>
		<h6 style="color:black;"><strong>Campus Placement Policy for Students of University Campus and Affiliated Colleges</strong></h6><br>
		<p>The placement policy guidelines are as follows:</p>
		<ul>
		<li>At the beginning of the academic calendar, students will be subjected to aptitude tests or counseled to chalk out their career plan- whether to pursue higher education or to seek an employment.</li>
		<li>The students who wish to apply to a particular company/organization are required to submit their willingness to the Training and Placement Office before the specified deadline. No late entries will be entertained under any circumstances. It is obligatory on the part of these students to attend the interviews.</li>
		<li>The Training and Placement Office will provide opportunities to all its registered students to secure one job at the first instance, and pursues a policy of one student- one job till at least 50/70/80% (depending upon the discipline) of the students in a particular branch/discipline get a job.</li>
		<li>Once 50-80% of the class gets one job, the students already having a job will be eligible to apply for another job. A student who has obtained a second job in this fashion will not be allowed to appear for any more interviews.</li>
		<li>After all the students of a department/school/affiliated colleges have secured at least one job, all of them will be allowed to apply for all subsequent jobs (subject to securing a maximum of two jobs).</li>
		<li>If a student is offered a second job, he/she must give a letter of regret to the company, which offered the first job and a letter of acceptance to the second.</li>
		<li>After accepting a job offer, if any student decides to withdraw his/her acceptance any time during the year, he/she must inform the company concerned through the Training and Placement Office immediately.</li>
		<li>The students selected through campus interview will complete all the necessary formalities (e.g. medical test) asked by the employer and will join the organization within stipulated time frame. He/ she will keep the T & P Cell update regarding his/ her progress in the Company. T & P Cell, in turn, will obtain regular feedback from the employer regarding the performance of selected students. As a matter of policy, the selected students will work at least for the duration of one year in that Organisation.</li>
		</ul>
	  </div>
	</section>
	
	
	
	
	
	
	<div id="adminlogin" class="modal">
  
  <form class="modal-content animate" >
    <div class="Aimgcontainer">
	  <h3><strong>Admin Login</strong></h3>
      <span onclick="document.getElementById('adminlogin').style.display='none'" class="close" title="Close Modal">&times;</span>
    </div>
    <div class="Acontainer">
	  <div class="alert alert-danger" id="adminLoginAlert" style="display:none" ></div>
      <label for="auname"><b>Username</b></label>
      <input type="text" class="A" placeholder="Enter Username" name="auname" id="auname">

      <label for="apsw"><b>Password</b></label>
      <input type="password" class="A" placeholder="Enter Password" name="apsw" id="apsw">
        
      <button type="button" id="alogin" class="B">Login</button>
    </div>

    <div class="Acontainer" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('adminlogin').style.display='none'" class="B BC">Cancel</button>
    </div>
  </form>
</div>



	
		
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-6">
        	<div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About the Academic Programs</h2>
              <p>Faculty of Engineering<br>Faculty of Management and Commerce<br>Faculty of Design<br>Faculty of Science<br>Faculty of Arts and Law</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4" align="right">
            	<h2 class="ftco-heading-2">Quick Contacts</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="text">Manipal University Jaipur, Rajasthan 303007</span<span class="icon icon-map-marker"></span></li>
	                <li><span class="text">+2 392 3929 210</span><span class="icon icon-phone"></span></li>
	                <li><span class="text">placement@muj.edu.in</span><span class="icon icon-envelope"></span></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script>
	var modal1 = document.getElementById('adminlogin');	
	window.onclick = function(event) {
    if (event.target == modal1) {
        modal1.style.display = "none";
    }
	}
	
	$("#alogin").click(function(){
		$.ajax({
			type: "POST",
			url: "actions.php?action=adminlogin",
			data: "auname="+$("#auname").val()+"&apsw="+$("#apsw").val(),
			success: function(result) {	
				if(result == 1) {
					window.location.assign("http://localhost/Training-and-Placement/dashboard.php");	
				} else {			
					$("#adminLoginAlert").html(result).show();		
				}
			}	
		})
	})
	
	
	
  </script>
  </body>
</html>