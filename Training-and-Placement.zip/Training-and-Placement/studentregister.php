 <?php include("functions.php"); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Training and Placement Portal</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php">Training and Placement Portal</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	    </div>
	  </nav>
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background-image: url('images/muj.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start" data-scrollax-parent="true">
          <div class="col-md-8 ftco-animate text-center text-md-left mb-5" data-scrollax=" properties: { translateY: '70%' }">
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Register to get placed</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-4 pb-1">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <h2>Registration</h2>
          </div>
        </div>
		<form>
		<div class="alert alert-danger" id="studentRegistrationAlert" style="display:none" ></div>
		<div class="form-group row">
			<label for="sruname" class="col-sm-2 col-form-label">Username</label>
			<div class="col-sm-10">
				<input type="email" class="form-control" id="suname" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="srpsw" class="col-sm-2 col-form-label">Password</label>
			<div class="col-sm-10">
				<input type="password" class="form-control" id="spsw" style="width:700px; height:40px !important;">
			</div>
		</div>
		<hr>
            <h6 style="color:black;"><strong>Please fill up details. (These details can be used as your CV)</strong></h6><br>
		<div class="form-group row">
			<label for="srname" class="col-sm-2 col-form-label col-form-label">Student's Name</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="sname" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="srfname" class="col-sm-2 col-form-label">Father's Name</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="sfname" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="srmname" class="col-sm-2 col-form-label">Mother's Name</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="smname" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<div class="col-form-label col-sm-2">Gender</div>
			<div class="col-sm-10">
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="sgender" value="Male" >
				<label class="form-check-label" for="sgender">Male</label>
			</div>
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="sgender" id="inlineRadio2" value="Female" >
				<label class="form-check-label" for="sgender">Female</label>
			</div>
			</div>
		</div>
		<div class="form-group row">
			<label for="srbdate" class="col-sm-2 col-form-label">Birth Date</label>
			<div class="col-sm-10">
				<input type="date" class="form-control" id="sbdate" style="width:700px; height:40px !important; color:grey !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="sremail" class="col-sm-2 col-form-label">Email Id</label>
			<div class="col-sm-10">
				<input type="email" class="form-control" id="semail" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="sradd" class="col-sm-2 col-form-label">Address</label>
			<div class="col-sm-10">
				<textarea class="form-control" id="sadd" style="width:700px; height:40px !important resizeable:none;"></textarea>
			</div>
		</div>
		<div class="form-group row">
			<label for="srmob" class="col-sm-2 col-form-label">Mobile</label>
			<div class="col-sm-10">
				<input type="tel" class="form-control" id="smob" style="width:700px; height:40px !important;" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" required>
			</div>
		</div>
		<div class="form-group row">
			<label for="srbranch" class="col-sm-2 col-form-label">Branch</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="sbranch" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="srcoll" class="col-sm-2 col-form-label">College Name</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="scoll" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="srsem" class="col-sm-2 col-form-label">Semester</label>
			<div class="col-sm-10">
				<input type="number" class="form-control" id="ssem" style="width:700px; height:40px !important;" min="1" max="8">
			</div>
		</div>
		<div class="form-group row">
			<label for="sr10per" class="col-sm-2 col-form-label">10th Percentage</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="s10per" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="srpy10per" class="col-sm-2 col-form-label">Passing Year of 10th</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="spy10" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="sr12per" class="col-sm-2 col-form-label">12th Percenatge</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="s12per" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="srpy12per" class="col-sm-2 col-form-label">Passing Year of 12th</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="spy12" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="sr1yearper" class="col-sm-2 col-form-label">1st Year Percentage</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="s1yearper" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="sr2yearper" class="col-sm-2 col-form-label">2nd Year Percentage</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="s2yearper" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="sr3yearper" class="col-sm-2 col-form-label">3rd Year Percentage</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="s3yearper" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="sr4yearper" class="col-sm-2 col-form-label">4th Year Percentage</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="s4yearper" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="srbaclog" class="col-sm-2 col-form-label">Any Backlog?</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="sbacklog" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="srcgpa" class="col-sm-2 col-form-label">CPGA (upto now)</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="scgpa" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="srgradyear" class="col-sm-2 col-form-label">Graduating Year</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="sgradyear" style="width:700px; height:40px !important;">
			</div>
		</div><br>
		<div class="form-group row">
			<div class="col-sm-10">
				<button type="button" class="btn btn-success" name="Register" id="studentRegister">Register</button>
			</div>
		</div>
		</form>
    </div>
    </section>
		
		<footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-6">
        	<div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About the Academic Programs</h2>
              <p>Faculty of Engineering<br>Faculty of Management and Commerce<br>Faculty of Design<br>Faculty of Science<br>Faculty of Arts and Law</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4" align="right">
            	<h2 class="ftco-heading-2">Quick Contacts</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="text">Manipal University Jaipur, Rajasthan 303007</span<span class="icon icon-map-marker"></span></li>
	                <li><span class="text">+2 392 3929 210</span><span class="icon icon-phone"></span></li>
	                <li><span class="text">placement@muj.edu.in</span><span class="icon icon-envelope"></span></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
	
	<script>
	
		$("#studentRegister").click(function(){
		$.ajax({
			type: "POST",
			url: "actions.php?action=studentregister",
			data: "suname="+$("#suname").val()+"&spsw="+$("#spsw").val()+"&sname="+$("#sname").val()+"&sfname="+$("#sfname").val()+"&smname="+$("#smname").val()+"&sgender="+$("input[name=sgender]:checked").val()+"&sbdate="+$("#sbdate").val()+"&semail="+$("#semail").val()+"&sadd="+$("#sadd").val()+"&smob="+$("#smob").val()+"&sbranch="+$("#sbranch").val()+"&scoll="+$("#scoll").val()+"&ssem="+$("#ssem").val()+"&s10per="+$("#s10per").val()+"&spy10="+$("#spy10").val()+"&s12per="+$("#s12per").val()+"&spy12="+$("#spy12").val()+"&s1yearper="+$("#s1yearper").val()+"&s2yearper="+$("#s2yearper").val()+"&s3yearper="+$("#s3yearper").val()+"&s4yearper="+$("#s4yearper").val()+"&sbacklog="+$("#sbacklog").val()+"&scgpa="+$("#scgpa").val()+"&sgradyear="+$("#sgradyear").val(),
			success: function(result) {	
				if(result == 1) {
					window.location.assign("http://localhost/Training-and-Placement/dashboard.php");	
				} else {			
					$("#studentRegistrationAlert").html(result).show();		
				}
			}	
		})
	})
	
	</script>
    
  </body>
</html>