<?php
	include("functions.php");
	$output='';
	if (isset($_POST["filter"])) {
		$query = "SELECT * FROM students WHERE `scgpa` > '".$_POST['fcgpa']."' AND `sbacklog` = '".$_POST['fbacklog']."' AND `sbranch` = '".$_POST['fprogram']."' ";
		$result = mysqli_query($link,$query);
		if(mysqli_num_rows($result)>0) {
			$output.='
			<table class="table" bordered="1">
			<tr>
			<th>Name</th>
			<th>CGPA</th>
			<th>Email ID</th>
			<tr>
			';
			while($row=mysqli_fetch_array($result)) {
				$output .= '
				<tr>
				<td>'.$row["sname"].'</td>
				<td>'.$row["scgpa"].'</td>
				<td>'.$row["semail"].'</td>
				';
			}
			$output .='</table>';
			header("Content-Type: application/xls");
			header("Content-Disposition: attachment; filename=download.xls");
			echo $output;
		}
		
	}
	

?>