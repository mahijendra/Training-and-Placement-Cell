 <?php 
 
	include("functions.php");
 
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Training and Placement Portal</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.html">Training and Placement Portal</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	       <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
			  <?php if(isset($_SESSION['cid'])) { ?>
			  <li class="nav-item active"><a href="studentdetails.php" class="nav-link">Student Details</a></li>
			  <?php } ?>
			  <?php if(isset($_SESSION['sid'])) { ?>
			  <li class="nav-item"><a href="companydetails.php" class="nav-link">Company Details</a></li>
			  <?php } ?>
	          <li class="nav-item"><a href="procedure.php" class="nav-link">Procedure</a></li>
			  <?php if(isset($_SESSION['aid'])) { ?>
				<li class="nav-item active"><a href="studentdetails.php" class="nav-link">Student Details</a></li>
				<li class="nav-item"><a class="nav-link" href="#" onclick="document.getElementById('announcements').style.display='block'">Add Anouncements</a></li>
			  <?php } ?>
			  <?php if(isset($_SESSION['sid']) or isset($_SESSION['cid']) or isset($_SESSION['aid'])) { ?>
				<li class="nav-item"><a href="?function=logout" class="nav-link btn-outline-danger" style="border-radius:15px;" >Logout</a></li>
			  <?php } else { ?>
				<li class="nav-item"><a href="login.php" class="nav-link">Login</a></li>
				<li class="nav-item"><a class="nav-link" href="#" onclick="document.getElementById('adminlogin').style.display='block'">Admin Login</a></li>
			  <?php } ?>
			  

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background-image: url('images/muj.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start" data-scrollax-parent="true">
          <div class="col-md-8 ftco-animate text-center text-md-left mb-5" data-scrollax=" properties: { translateY: '70%' }">
          	<p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-3"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Student Details</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Student Details</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-4 pb-1">
          <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Student's Name</th>
      <th scope="col">Branch</th>
      <th scope="col">Semester</th>
      <th scope="col">CGPA</th>
	  <th></th>
    </tr>
  </thead>
  <tbody>
  <?php 
	$query="SELECT * FROM students ORDER BY `sid`";
	$result=mysqli_query($link,$query);
	if(mysqli_num_rows($result) == 0) {
		echo "There are no students to display";	
	} else {
		while($row=mysqli_fetch_assoc($result)) {
			echo "<tr>
					<th scope='row'>".$row['sname']."</th>
					<td>".$row['sbranch']."</td>
					<td>".$row['ssem']."</td>
					<td>".$row['scgpa']."</td>
					<td><a href='http://localhost/Training-and-Placement/profile.php?userid=".$row['sid']."'><button type='button' class='btn btn-success' >View Profile</button></a></td>
				</tr>";
		}
	}
	
  
  ?>
  </tbody>
  </table>
        </div>
      </div>
    </section>
	
	
	<div id="announcements" class="modal">
  
  <form class="modal-content animate" >
    <div class="Aimgcontainer">
	  <h3><strong>Add Announcements</strong></h3>
      <span onclick="document.getElementById('announcements').style.display='none'" class="close" title="Close Modal">&times;</span>
    </div>
    <div class="Acontainer">
	  <div class="alert alert-danger" id="announcementsAlert" style="display:none" ></div>
      <label for="antitle"><b>Title</b></label>
      <input type="text" class="A" placeholder="Enter Username" name="antitle" id="antitle">
	  <hr>
      <label for="andes"><b>Description</b></label>
	  <textarea class="A" id="andes" style="resizeable:none;"></textarea>
        
      <button type="button" id="ansubmit" class="B">Submit</button>
    </div>

    <div class="Acontainer" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('announcements').style.display='none'" class="B BC">Cancel</button>
    </div>
  </form>
</div>
	
		
		<footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-6">
        	<div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About the Academic Programs</h2>
              <p>Faculty of Engineering<br>Faculty of Management and Commerce<br>Faculty of Design<br>Faculty of Science<br>Faculty of Arts and Law</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4" align="right">
            	<h2 class="ftco-heading-2">Quick Contacts</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="text">Manipal University Jaipur, Rajasthan 303007</span<span class="icon icon-map-marker"></span></li>
	                <li><span class="text">+2 392 3929 210</span><span class="icon icon-phone"></span></li>
	                <li><span class="text">placement@muj.edu.in</span><span class="icon icon-envelope"></span></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>

  

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script>

	
	var modal2 = document.getElementById('announcements');	
	window.onclick = function(event) {
    if (event.target == modal2) {
        modal2.style.display = "none";
    }
	}
	
	$("#ansubmit").click(function(){
		$.ajax({
			type: "POST",
			url: "actions.php?action=announcements",
			data: "antitle="+$("#antitle").val()+"&andes="+$("#andes").val(),
			success: function(result) {	
				if(result == 1) {
					document.getElementById("antitle").value="";
					document.getElementById("andes").value="";
					modal2.style.display = "none";
					swal("Success!", "Announcement added succesfully!", "success");
				} else {			
					$("#announcementsAlert").html(result).show();		
				}
			}	
		})
	})
	</script>
  
  </body>
</html>