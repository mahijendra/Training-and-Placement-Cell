 <?php include("functions.php"); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Training and Placement Portal</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php">Training and Placement Portal</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	    </div>
	  </nav>
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background-image: url('images/muj.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start" data-scrollax-parent="true">
          <div class="col-md-8 ftco-animate text-center text-md-left mb-5" data-scrollax=" properties: { translateY: '70%' }">
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">New Company Registration</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-4 pb-1">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <h2>Registration</h2>
          </div>
        </div>
		<form> 
		<div class="alert alert-danger" id="companyRegistrationAlert" style="display:none" ></div>
		<div class="form-group row">
			<label for="cuname" class="col-sm-2 col-form-label">Email Id</label>
			<div class="col-sm-10">
				<input type="email" class="form-control" id="cuname" style="width:700px; height:40px !important;">
			</div>
		</div>
		<hr>
		<h6 style="color:black;"><strong>Comapany Details</strong></h6><br>
		<div class="form-group row">
			<label for="cname" class="col-sm-2 col-form-label col-form-label">Comapany Name</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="cname" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="cpsw" class="col-sm-2 col-form-label col-form-label">Password</label>
			<div class="col-sm-10">
				<input type="password" class="form-control" id="cpsw" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="cwebsite" class="col-sm-2 col-form-label col-form-label">Website</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="cwebsite" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="cnatureofbusiness" class="col-sm-2 col-form-label col-form-label">Nature of Business</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="cnatureofbusiness" style="width:700px; height:40px !important;">
			</div>
		</div>
		<hr>
		<h6 style="color:black;"><strong>Contact Details</strong></h6><br>
		<div class="form-group row">
			<label for="cnamecontact" class="col-sm-2 col-form-label">Name</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="cnamecontact" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="cdesignation" class="col-sm-2 col-form-label">Designation</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="cdesignation" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="ccontactnum" class="col-sm-2 col-form-label">Contact Number</label>
			<div class="col-sm-10">
				<input type="tel" class="form-control" id="ccontactnum" style="width:700px; height:40px !important;" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" required>
			</div>
		</div>
		<div class="form-group row">
			<label for="clandline" class="col-sm-2 col-form-label">Landline Number</label>
			<div class="col-sm-10">
				<input type="tel" class="form-control" id="clandline" style="width:700px; height:40px !important;" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" required>
			</div>
		</div>
		<div class="form-group row">
			<label for="cemail" class="col-sm-2 col-form-label">Alternate Email Id</label>
			<div class="col-sm-10">
				<input type="email" class="form-control" id="cemail" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="cfax" class="col-sm-2 col-form-label">Fax</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="cfax" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="cadd" class="col-sm-2 col-form-label">Address</label>
			<div class="col-sm-10">
				<textarea class="form-control" id="cadd" style="width:700px; height:40px !important resizeable:none;"></textarea>
			</div>
		</div>
		<hr>
		<h6 style="color:black;"><strong>Job Details</strong></h6><br>
		<div class="form-group row">
			<label for="cjobdesoffered" class="col-sm-2 col-form-label col-form-label">Job Designation Offered</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="cjobdesoffered" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="coffer" class="col-sm-2 col-form-label col-form-label">Type of Offer</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="coffer" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<legend class="col-form-label col-sm-2">Start Up</legend>
			<div class="col-sm-10">
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="cstartup" id="inlineRadio1" value="Yes">
				<label class="form-check-label" for="cstartup">Yes</label>
			</div>
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="cstartup" id="inlineRadio2" value="No">
				<label class="form-check-label" for="cstartup">No</label>
			</div>
			</div>
		</div>
		<div class="form-group row">
			<label for="cnatureofprofile" class="col-sm-2 col-form-label">Nature of Profile</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="cnatureofprofile" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="coffersmade" class="col-sm-2 col-form-label col-form-label">Probable no. of offers to be made</label>
			<div class="col-sm-10">
				<input type="text" class="form-control" id="coffersmade" style="width:700px; height:40px !important;">
			</div>
		</div>
		<div class="form-group row">
			<label for="cjobdescription" class="col-sm-2 col-form-label">Job Description</label>
			<div class="col-sm-10">
				<textarea class="form-control" id="cjobdescription" style="width:700px; height:40px !important resizeable:none;"></textarea>
			</div>
		</div>
		<div class="form-group row">
			<label for="cbonddetails" class="col-sm-2 col-form-label">Details of Bond If Any</label>
			<div class="col-sm-10">
				<textarea class="form-control" id="cbonddetails" style="width:700px; height:40px !important resizeable:none;"></textarea>
			</div>
		</div>
		<div class="form-group row">
			<legend class="col-form-label col-sm-2">Medical Test</legend>
			<div class="col-sm-10">
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="cmedtest" id="inlineRadio1" value="Yes">
				<label class="form-check-label" for="cmedtest">Yes</label>
			</div>
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="cmedtest" id="inlineRadio2" value="On">
				<label class="form-check-label" for="cmedtest">No</label>
			</div>
			</div>
		</div>
		<hr>
		<h6 style="color:black;"><strong>Selction Process</strong></h6><br>
		<div class="form-group row">
			<legend class="col-form-label col-sm-2">Group Discussion</legend>
			<div class="col-sm-10">
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="cgroupdiscussion" id="inlineRadio1" value="Yes">
				<label class="form-check-label" for="cgroupdiscussion">Yes</label>
			</div>
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="cgroupdiscussion" id="inlineRadio2" value="No">
				<label class="form-check-label" for="cgroupdiscussion">No</label>
			</div>
			</div>
		</div>
		<div class="form-group row">
			<legend class="col-form-label col-sm-2">Interview</legend>
			<div class="col-sm-10">
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="cinterview" id="inlineRadio1" value="Personal">
				<label class="form-check-label" for="cinterview">Personal</label>
			</div>
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="cinterview" id="inlineRadio2" value="Telephonic">
				<label class="form-check-label" for="cinterview">Telephonic</label>
			</div>
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="cinterview" id="inlineRadio1" value="Skype">
				<label class="form-check-label" for="cinterview">Skype</label>
			</div>
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="cinterview" id="inlineRadio2" value="Video Conferencing">
				<label class="form-check-label" for="cinterview">Video Conferencing</label>
			</div>
			</div>
		</div>
		<div class="form-group row">
			<legend class="col-form-label col-sm-2">Aptitude Test</legend>
			<div class="col-sm-10">
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="captitudetest" id="inlineRadio1" value="Yes">
				<label class="form-check-label" for="captitudetest">Yes</label>
			</div>
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="captitudetest" id="inlineRadio2" value="No">
				<label class="form-check-label" for="captitudetest">No</label>
			</div>
			</div>
		</div>
		<div class="form-group row">
			<legend class="col-form-label col-sm-2">Technical Test</legend>
			<div class="col-sm-10">
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="ctechnicaltest" id="inlineRadio1" value="Yes">
				<label class="form-check-label" for="ctechnicaltest">Yes</label>
			</div>
			<div class="form-check form-check-inline">
				<input class="form-check-input" type="radio" name="ctechnicaltest" id="inlineRadio2" value="No">
				<label class="form-check-label" for="ctechnicaltest">No</label>
			</div>
			</div>
		</div>
		<div class="form-group row">
			<label for="ctestrequirements" class="col-sm-2 col-form-label">Test Requirements</label>
			<div class="col-sm-10">
				<textarea class="form-control" id="ctestrequirements" style="width:700px; height:40px !important resizeable:none;"></textarea>
			</div>
		</div>
		<hr>
		<h6 style="color:black;"><strong>Please select the programs you wish to recruit from.</strong></h6><br>
		<h6 style="color:red;"><strong>Undergraduate Degree</strong></h6><br>
		<div class="form-group row">
			<legend class="col-form-label col-sm-2" ><strong>B.Tech</strong></legend>
			<div class="col-sm-10">
			<div class="form-check form-check-inline col-sm-4">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio1" value="Chemical Engineering">
				<label class="form-check-label" for="cprogram">Chemical Engineering</label>
			</div>
			<div class="form-check form-check-inline col-sm-6">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio2" value="Civil Engineering">
				<label class="form-check-label" for="cprogram">Civil Engineering</label>
			</div>
			</div>
		</div>
		<div class="form-group row">
			<div class="col-form-label col-sm-2"></div>
			<div class="col-sm-10">
			<div class="form-check form-check-inline col-sm-4">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio1" value="Computer Science Engineering">
				<label class="form-check-label" for="cprogram">Computer Science Engineering</label>
			</div>
			<div class="form-check form-check-inline col-sm-6">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio2" value="Electrical Engineering">
				<label class="form-check-label" for="cprogram">Electrical Engineering</label>
			</div>
			</div>
		</div>
		<div class="form-group row">
			<div class="col-form-label col-sm-2"></div>
			<div class="col-sm-10">
			<div class="form-check form-check-inline col-sm-4">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio1" value="Mechanical Engineering">
				<label class="form-check-label" for="cprogram">Mechanical Engineering</label>
			</div>
			<div class="form-check form-check-inline col-sm-6">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio2" value="Electrical and Communication Engineering">
				<label class="form-check-label" for="cprogram">Electrical and Communication Engineering</label>
			</div>
			</div>
		</div>
		<div class="form-group row">
			<div class="col-form-label col-sm-2"></div>
			<div class="col-sm-10">
			<div class="form-check form-check-inline col-sm-4">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio1" value="Information Technology Engineering">
				<label class="form-check-label" for="cprogram">Information Technology Engineering</label>
			</div>
			<div class="form-check form-check-inline col-sm-6">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio2" value="Computer and Communication Engineering">
				<label class="form-check-label" for="cprogram">Computer and Communication Engineering</label>
			</div>
			</div>
		</div><br>
		<h6 style="color:red;"><strong>Postgraduate Degree</strong></h6><br>
		<div class="form-check form-check-inline col-sm-12">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio1" value="M.Tech">
				<label class="form-check-label" for="cprogram">M.Tech</label>
		</div>
		<p><small>[MTech is a 4 semester Master's program.These students are admitted based on GATE score.]</small></p>
		<div class="form-check form-check-inline col-sm-12">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio1" value="M.S">
				<label class="form-check-label" for="cprogram">M.S</label>
		</div>
		<p><small>[MS is a Master's degree by Research. Theses students are admitted based on their GATE/CSIR Scores and a Personal Interview/Writtens Tests by the Departments.]</small></p>
		<div class="form-check form-check-inline col-sm-12">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio1" value="M.Sc">
				<label class="form-check-label" for="cprogram">M.Sc</label>
		</div>
		<p></p>
		<div class="form-check form-check-inline col-sm-12">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio1" value="M.A">
				<label class="form-check-label" for="cprogram">M.A</label>
		</div>
		<p></p>
		<div class="form-check form-check-inline col-sm-12">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio1" value="M.B.A">
				<label class="form-check-label" for="cprogram">M.B.A</label>
		</div>
		<p></p>
		<br>
		<h6 style="color:red;"><strong>Doctrate</strong></h6><p></p>
		<div class="form-check form-check-inline col-sm-12">
				<input class="form-check-input" type="checkbox" name="cprogram" id="inlineRadio1" value="Ph.D">
				<label class="form-check-label" for="cprogram">Ph.D</label>
		</div>
		<p></p>
		<br>
		<div class="form-group row">
			<div class="col-sm-10">
				<button type="button" class="btn btn-success" id="companyRegister">Register</button>
			</div>
		</div>
		</form>
    </div>
    </section>
		
		<footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-6">
        	<div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About the Academic Programs</h2>
              <p>Faculty of Engineering<br>Faculty of Management and Commerce<br>Faculty of Design<br>Faculty of Science<br>Faculty of Arts and Law</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4" align="right">
            	<h2 class="ftco-heading-2">Quick Contacts</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="text">Manipal University Jaipur, Rajasthan 303007</span<span class="icon icon-map-marker"></span></li>
	                <li><span class="text">+2 392 3929 210</span><span class="icon icon-phone"></span></li>
	                <li><span class="text">placement@muj.edu.in</span><span class="icon icon-envelope"></span></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
	
	<script>
	
		$("#companyRegister").click(function(){
		var ids = [];
            $.each($("input[name='cprogram']:checked"), function(){
                ids.push($(this).val());
            });
		$.ajax({
			type: "POST",
			url: "actions.php?action=companyregister",
			data: "cuname="+$("#cuname").val()+"&cname="+$("#cname").val()+"&cpsw="+$("#cpsw").val()+"&cwebsite="+$("#cwebsite").val()+"&cnatureofbusiness="+$("#cnatureofbusiness").val()+"&cnamecontact="+$("#cnamecontact").val()+"&cdesignation="+$("#cdesignation").val()+"&ccontactnum="+$("#ccontactnum").val()+"&clandline="+$("#clandline").val()+"&cemail="+$("#cemail").val()+"&cfax="+$("#cfax").val()+"&cadd="+$("#cadd").val()+"&cjobdesoffered="+$("#cjobdesoffered").val()+"&coffer="+$("#coffer").val()+"&cstartup="+$("input[name=cstartup]:checked").val()+"&cnatureofprofile="+$("#cnatureofprofile").val()+"&coffersmade="+$("#coffersmade").val()+"&cjobdescription="+$("#cjobdescription").val()+"&cbonddetails="+$("#cbonddetails").val()+"&cmedtest="+$("input[name=cmedtest]:checked").val()+"&cgroupdiscussion="+$("input[name=cgroupdiscussion]:checked").val()+"&cinterview="+$("input[name=cinterview]:checked").val()+"&captitudetest="+$("input[name=captitudetest]:checked").val()+"&ctechnicaltest="+$("input[name=ctechnicaltest]:checked").val()+"&ctestrequirements="+$("#ctestrequirements").val()+"&cprogram="+ids.join(', '),
			success: function(result) {	
				if(result == 1) {
					window.location.assign("http://localhost/Training-and-Placement/dashboard.php");	
				} else {			
					$("#companyRegistrationAlert").html(result).show();		
				}
			}	
		})
	})
	
	</script>

    
  </body>
</html>