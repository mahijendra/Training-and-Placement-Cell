 <?php include("functions.php"); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Training and Placement Portal</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,600,700,800,900" rel="stylesheet">
	
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
	
    <link rel="stylesheet" href="css/style.css">
	

  </head>
  <body>
    
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php">Training and Placement Portal</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	       <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="procedure.php" class="nav-link">Procedure</a></li>
			  <?php if(isset($_SESSION['sid']) or isset($_SESSION['cid']) or isset($_SESSION['aid'])) { ?>
				<li class="nav-item active"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
				<li class="nav-item"><a href="?function=logout" class="nav-link btn-outline-danger" style="border-radius:15px;" >Logout</a></li>
			  <?php } else { ?>
				<li class="nav-item"><a href="login.php" class="nav-link">Login</a></li>
				<li class="nav-item"><a class="nav-link" href="#" onclick="document.getElementById('adminlogin').style.display='block'">Admin Login</a></li>
			  <?php } ?>
			  

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
	
    <div class="hero-wrap js-fullheight" style="background-image: url('images/muj.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start" data-scrollax-parent="true">
          <div class="col-md-8 ftco-animate text-center text-md-left mb-5" data-scrollax=" properties: { translateY: '70%' }">
          	<p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><span class="mr-3"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Dashboard</span></p>
            <h1 class="mb-3 bread" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Dashboard</h1>
          </div>
        </div>
      </div>
    </div>
	
	<?php if(isset($_SESSION['aid'])) { ?>
	<section class="ftco-section bg-light">
      <div class="container">
	  <h2 style="font-weight:bold;font-family:Comic Sans MS,cursive, sans-serif;">WELCOME ADMIN !</h2><br><br>
        <ul class="nav nav-tabs nav-fill" id="myTab" role="tablist">
			<li class="nav-item" style="width:200px;">
				<a class="nav-link active" data-toggle="tab" href="#studentDetails" role="tab" style="height:70px;font-weight:bold;font-size:20px;;font-family:Comic Sans MS,cursive, sans-serif;" aria-controls="studenDetails">Student Details</a>
			</li>
			<li class="nav-item" style="width:200px;">
				<a class="nav-link" data-toggle="tab" href="#addAnnouncements" role="tab" style="height:70px;font-weight:bold;font-size:20px;;font-family:Comic Sans MS,cursive, sans-serif;" aria-controls="addAnnouncements">Add Announcements</a>
			</li>
			<li class="nav-item" style="width:200px;">
				<a class="nav-link" data-toggle="tab" href="#addCompanySchedule" role="tab" style="height:70px;font-weight:bold;font-size:20px;;font-family:Comic Sans MS,cursive, sans-serif;" aria-controls="updateCompanySchedule">Add Company Schedule</a>
			</li>
			<li class="nav-item" style="width:200px;">
				<a class="nav-link" data-toggle="tab" href="#filterStudents" role="tab"  style="height:70px;font-weight:bold;font-size:20px;;font-family:Comic Sans MS,cursive, sans-serif;" aria-controls="filterStudents">Filter Students</a>
			</li>
		</ul><br>
		
		<div class="tab-content">
			<div class="tab-pane active" id="studentDetails" role="tabpanel">
				<div class="row justify-content-center mb-4 pb-1" style="margin-left:3px;">
					<table class="table">
						<thead class="thead-dark">
							<tr>
								<th scope="col">Student's Name</th>
								<th scope="col">Branch</th>
								<th scope="col">Semester</th>
								<th scope="col">CGPA</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
						  <?php 
							$query="SELECT * FROM students ORDER BY `sid`";
							$result=mysqli_query($link,$query);
							if(mysqli_num_rows($result) == 0) {
								echo "There are no students to display";	
							} else {
								while($row=mysqli_fetch_assoc($result)) {
									echo "<tr>
											<th scope='row'>".$row['sname']."</th>
											<td>".$row['sbranch']."</td>
											<td>".$row['ssem']."</td>
											<td>".$row['scgpa']."</td>
											<td><a href='http://localhost/Training-and-Placement/profile.php?userid=".$row['sid']."'><button type='button' class='btn btn-success' >View Profile</button></a></td>
										</tr>";
								}
							}
							
  
						  ?>
						</tbody>
					</table>
				</div>
			</div>
			<div class="tab-pane" id="addAnnouncements" role="tabpanel">
				<form enctype="multipart/form-data" id="announcements">
					<div class="Acontainer">
						<div class="statusMsg"></div>
						<label for="antitle"><b>Title</b></label>
						<input type="text" class="A" placeholder="Enter Title" name="antitle" id="antitle">
						<hr>
						<label for="andes"><b>Description</b></label>
						<textarea class="A" id="andes" name="andes" style="resizeable:none;"></textarea>
						<label for="file"><b>Upload File</b></label><br>
						<input type="file" id="file" name="file"><br><br>						
						<button type="submit" name="announcementsubmit" class="B submitBtn">Submit</button>
					</div>
				</form>
			</div>
			
			<div class="tab-pane" id="addCompanySchedule" role="tabpanel">
				<br>
				<form id="updatecompschedule">
					<div class="alert alert-danger" id="addCompanyScheduleAlert" style="display:none" ></div>
					<div class="form-group row">
						<label for="schcname" class="col-sm-2 col-form-label">Company's Name</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="schcname" style="width:700px; height:40px !important;">
						</div>
					</div>
					<div class="form-group row">
						<label for="schdate" class="col-sm-2 col-form-label">Date</label>
						<div class="col-sm-10">
							<input type="date" class="form-control" id="schdate" style="width:700px; height:40px !important;">
						</div>
					</div>
					<div class="form-group row">
						<label for="schinterview" class="col-sm-2 col-form-label col-form-label">Interview Timings</label>
						<div class="col-sm-10">
							<input type="time" class="form-control" id="schinterview" style="width:700px; height:40px !important;">
						</div>
					</div>
					<div class="form-group row">
						<label for="schbacklog" class="col-sm-2 col-form-label">Backlog Allowed?</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="schbacklog" style="width:700px; height:40px !important;">
						</div>
					</div>
					<div class="form-group row">
						<label for="schminper" class="col-sm-2 col-form-label">Minimum Percentage Required</label>
						<div class="col-sm-10">
							<input type="number" class="form-control" id="schminper" style="width:700px; height:40px !important;">
						</div>
					</div>
					<div class="form-group row">
						<label for="schplacement" class="col-sm-2 col-form-label">Placement Type</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" id="schplacement" style="width:700px; height:40px !important;" min="1" max="8">
						</div>
					</div>
						<label class="col-form-label">Eligible Programs</label><br>
					<div class="form-group row">
						<legend class="col-form-label col-sm-2" ><strong>B.Tech</strong></legend>
						<div class="col-sm-10">
						<div class="form-check form-check-inline col-sm-4">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="Chemical Engineering">
							<label class="form-check-label" for="schprogram">Chemical Engineering</label>
						</div>
						<div class="form-check form-check-inline col-sm-6">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="Civil Engineering">
							<label class="form-check-label" for="schprogram">Civil Engineering</label>
						</div>
						</div>
					</div>
					<div class="form-group row">
						<div class="col-form-label col-sm-2"></div>
						<div class="col-sm-10">
						<div class="form-check form-check-inline col-sm-4">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="Computer Science Engineering">
							<label class="form-check-label" for="schprogram">Computer Science Engineering</label>
						</div>
						<div class="form-check form-check-inline col-sm-6">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="Electrical Engineering">
							<label class="form-check-label" for="schprogram">Electrical Engineering</label>
						</div>
						</div>
					</div>
					<div class="form-group row">
						<div class="col-form-label col-sm-2"></div>
						<div class="col-sm-10">
						<div class="form-check form-check-inline col-sm-4">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="Mechanical Engineering">
							<label class="form-check-label" for="schprogram">Mechanical Engineering</label>
						</div>
						<div class="form-check form-check-inline col-sm-6">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="Electrical and Communication Engineering">
							<label class="form-check-label" for="schprogram">Electrical and Communication Engineering</label>
						</div>
						</div>
					</div>
					<div class="form-group row">
						<div class="col-form-label col-sm-2"></div>
						<div class="col-sm-10">
						<div class="form-check form-check-inline col-sm-4">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="Information Technology Engineering">
							<label class="form-check-label" for="schprogram">Information Technology Engineering</label>
						</div>
						<div class="form-check form-check-inline col-sm-6">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="Computer and Communication Engineering">
							<label class="form-check-label" for="schprogram">Computer and Communication Engineering</label>
						</div>
						</div>
					</div>
					<h6 class="col-form-label"><strong>Postgraduate Degree</strong></h6>
					<div class="form-check form-check-inline col-sm-12">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="M.Tech">
							<label class="form-check-label" for="schprogram">M.Tech</label>
					</div>
					<p><small>[MTech is a 4 semester Master's program.These students are admitted based on GATE score.]</small></p>
					<div class="form-check form-check-inline col-sm-12">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="M.S">
							<label class="form-check-label" for="schprogram">M.S</label>
					</div>
					<p><small>[MS is a Master's degree by Research. Theses students are admitted based on their GATE/CSIR Scores and a Personal Interview/Writtens Tests by the Departments.]</small></p>
					<div class="form-check form-check-inline col-sm-12">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="M.Sc">
							<label class="form-check-label" for="schprogram">M.Sc</label>
					</div>
					<p></p>
					<div class="form-check form-check-inline col-sm-12">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="M.A">
							<label class="form-check-label" for="schprogram">M.A</label>
					</div>
					<p></p>
					<div class="form-check form-check-inline col-sm-12">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="M.B.A">
							<label class="form-check-label" for="schprogram">M.B.A</label>
					</div>
					<p></p>
					<h6 class="col-form-label"><strong>Doctrate</strong></h6><p></p>
					<div class="form-check form-check-inline col-sm-12">
							<input class="form-check-input" type="checkbox" name="schprogram" id="schprogram" value="Ph.D">
							<label class="form-check-label" for="schprogram">Ph.D</label>
					</div>
					<p></p>
					<br>
					<div class="form-group row">
						<div class="col-sm-10">
							<button type="button" class="btn btn-success" id="schedulebutton">Update</button>
						</div>
					</div>
				</form>			
			</div>
			<div class="tab-pane " id="filterStudents" role="tabpanel">
			<br>
				<form action="excel.php" method="post">
					<div class="alert alert-danger" id="filterStudentsAlert" style="display:none" ></div>
					 <h6 style="color:black;"><strong>Please fill up details on the basis of which you want to filter the Students.</strong></h6><br>
					<div class="form-group row">
						<label for="fcgpa" class="col-sm-2 col-form-label">CGPA</label>
						<div class="col-sm-10">
							<input type="number" class="form-control" name="fcgpa" style="width:700px; height:40px !important;">
						</div>
					</div>
					<div class="form-group row">
						<label for="fbacklog" class="col-sm-2 col-form-label col-form-label">Backlog</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="fbacklog" style="width:700px; height:40px !important;">
						</div>
					</div>
					<div class="form-group row">
						<label for="fprogram" class="col-sm-2 col-form-label col-form-label">Branch</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="fprogram" style="width:700px; height:40px !important;">
						</div>
					</div>
					<br>
					<div class="form-group row">
						<div class="col-sm-10">
							<button type="submit" name="filter" value="Filter Students" class="btn btn-success" id="filterbutton">Filter</button>
						</div>
					</div>
				</form>			
			</div>
		</div>
      </div>
    </section>
	<?php } ?>
	
	
	
	
	
	<?php if(isset($_SESSION['sid'])) { 
	$query="SELECT * FROM students WHERE `sid`=".$_SESSION['sid'];
	$result = mysqli_query($link,$query);
	$row = mysqli_fetch_assoc($result);
	?>
	<section class="ftco-section bg-light">
      <div class="container">
	  <h2 style="font-weight:bold;font-family:Comic Sans MS,cursive, sans-serif;">WELCOME <?php echo $row['sname'] ?> !</h2><br><br>
        <ul class="nav nav-tabs nav-fill" id="myTab" role="tablist">
			<li class="nav-item" style="width:200px;">
				<a class="nav-link active" data-toggle="tab" href="#announcements" role="tab" style="height:70px;font-weight:bold;font-size:20px;;font-family:Comic Sans MS,cursive, sans-serif;" aria-controls="announcements">Announcements</a>
			</li>
			<li class="nav-item" style="width:200px;">
				<a class="nav-link" data-toggle="tab" href="#companyDetails" role="tab" style="height:70px;font-weight:bold;font-size:20px;;font-family:Comic Sans MS,cursive, sans-serif;" aria-controls="companyDetails">Company Details</a>
			</li>
		</ul><br>
		
		<div class="tab-content">
			<div class="tab-pane active" id="announcements" role="tabpanel">
				<?php 
					$query="SELECT * FROM announcements ORDER BY `anid`";
					$result=mysqli_query($link,$query);
					if(mysqli_num_rows($result)==0) {
						echo "<p class='alert alert-danger' >There are no announcemets to display</p>";
					} else {
						while($row=mysqli_fetch_assoc($result)) {
							echo "<div class='well' style='border-style:groove;padding:25px;border-radius:12px;'>";
							echo "<h5 style='font-weight:bold;font-family:Trebuchet MS, Helvetica, sans-serif;text-decoration:underline;text-align:center;color:black;font-size:21px;'>".$row['antitle']."</h5>";
							echo "<p style='font-family:Trebuchet MS, Helvetica, sans-serif;color:grey;font-weight:bold;font-size:18px;'>".$row['andes']."</p>";
							if($row['anfile']!="") {
								echo "<a href='uploads/".$row['anfile']."'>Download Attachment</a>";
							}
							echo "</div>";
							echo "<br>";
						}
					}
				?>
			</div>
			<div class="tab-pane" id="companyDetails" role="tabpanel">
				<div class="row justify-content-center mb-4 pb-1">
				<table class="table">
					<thead class="thead-dark">
						<tr>
						  <th scope="col">Company's Name</th>
						  <th scope="col">Nature of Business</th>
						  <th scope="col">Contact Number</th>
						  <th scope="col">Email Id</th>
						  <th></th>
						  <th></th>
						</tr>
					</thead>
					<tbody>
					  <?php 
						$query="SELECT * FROM company ORDER BY `cid`";
						$result=mysqli_query($link,$query);
						if(mysqli_num_rows($result) == 0) {
							echo "There are no companies to display";	
						} else {
							while($row=mysqli_fetch_assoc($result)) {
								echo "<tr>
										<th scope='row'>".$row['cname']."</th>
										<td>".$row['cnatureofbusiness']."</td>
										<td>".$row['ccontactnum']."</td>
										<td>".$row['cemail']."</td>
										<td><a href='http://localhost/Training-and-Placement/companyprofile.php?userid=".$row['cid']."'><button type='button' class='btn btn-success' >View Profile</button></a></td>
										<td><a href='http://localhost/Training-and-Placement/companyschedule.php?userid=".$row['cid']."'><button type='button' class='btn btn-success' >View Schedule</button></a></td>
									</tr>";
							}
						}
					  ?>
					</tbody>
				</table>
				</div>
			</div>
		</div>
      </div>
    </section>
	<?php } ?>
	
	
	
	<?php if(isset($_SESSION['cid'])) { 
	$query="SELECT * FROM company WHERE `cid`=".$_SESSION['cid'];
	$result = mysqli_query($link,$query);
	$row = mysqli_fetch_assoc($result);
	?>
	<section class="ftco-section bg-light">
      <div class="container">
	  <h2 style="font-weight:bold;font-family:Comic Sans MS,cursive, sans-serif;">WELCOME <?php echo $row['cname'] ?> !</h2><br><br>
        <ul class="nav nav-tabs nav-fill" id="myTab" role="tablist">
			<li class="nav-item" style="width:200px;">
				<a class="nav-link active" data-toggle="tab" href="#studentList" role="tab" style="height:70px;font-weight:bold;font-size:20px;;font-family:Comic Sans MS,cursive, sans-serif;" aria-controls="announcements">Students List</a>
			</li>
			
		</ul><br>
		
		<div class="tab-content">
			<div class="tab-pane active" id="studentList" role="tabpanel">
				<div class="container">
        <div class="row justify-content-center mb-4 pb-1">
          <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Student's Name</th>
      <th scope="col">Branch</th>
      <th scope="col">Semester</th>
      <th scope="col">CGPA</th>
	  <th></th>
    </tr>
  </thead>
  <tbody>
  <?php 
	$query="SELECT * FROM students ORDER BY `sid`";
	$result=mysqli_query($link,$query);
	if(mysqli_num_rows($result) == 0) {
		echo "There are no students to display";	
	} else {
		while($row=mysqli_fetch_assoc($result)) {
			echo "<tr>
					<th scope='row'>".$row['sname']."</th>
					<td>".$row['sbranch']."</td>
					<td>".$row['ssem']."</td>
					<td>".$row['scgpa']."</td>
					<td><a href='http://localhost/Training-and-Placement/profile.php?userid=".$row['sid']."'><button type='button' class='btn btn-success' >View Profile</button></a></td>
				</tr>";
		}
	}
	
  
  ?>
  </tbody>
  </table>
        </div>
      </div>
			</div>
		</div>
      </div>
    </section>
	<?php } ?>
	
	
	
	
	
		
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-6">
        	<div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">About the Academic Programs</h2>
              <p>Faculty of Engineering<br>Faculty of Management and Commerce<br>Faculty of Design<br>Faculty of Science<br>Faculty of Arts and Law</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4" align="right">
            	<h2 class="ftco-heading-2">Quick Contacts</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="text">Manipal University Jaipur, Rajasthan 303007</span<span class="icon icon-map-marker"></span></li>
	                <li><span class="text">+2 392 3929 210</span><span class="icon icon-phone"></span></li>
	                <li><span class="text">placement@muj.edu.in</span><span class="icon icon-envelope"></span></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
  
  <script>
	
	$(document).ready(function(e){
    $("#announcements").on('submit', function(e){
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'actions.php?action=addannouncements',
            data: new FormData(this),
            dataType: 'json',
            contentType: false,
            cache: false,
            processData:false,
            beforeSend: function(){
                $('.submitBtn').attr("disabled","disabled");
                $('#announcements').css("opacity",".5");
            },
            success: function(response){ 
                $('.statusMsg').html('');
                if(response.status == 1){
                    $('#announcements')[0].reset();
                    swal("Success!", "Announcement added succesfully!", "success");
                }else{
                    $('.statusMsg').html('<p class="alert alert-danger">'+response.message+'</p>');
                }
                $('#announcements').css("opacity","");
                $(".submitBtn").removeAttr("disabled");
            }
        });
    });
});
	
	
	
	
	$("#schedulebutton").click(function(){
		var ids = [];
            $.each($("input[name='schprogram']:checked"), function(){
                ids.push($(this).val());
            });
		$.ajax({
			type: "POST",
			url: "actions.php?action=companySchedule",
			data: "schcname="+$("#schcname").val()+"&schdate="+$("#schdate").val()+"&schinterview="+$("#schinterview").val()+"&schbacklog="+$("#schbacklog").val()+"&schminper="+$("#schminper").val()+"&schplacement="+$("#schplacement").val()+"&schprogram="+ids.join(', '),
			success: function(result) {	
				if(result == 1) {
					document.getElementById("updatecompschedule").reset();
					swal("Success!", "Company Schedule updated succesfully!", "success");
				} else {			
					$("#addCompanyScheduleAlert").html(result).show();		
				}
			}	
		})
	})
	
	
		
	
  </script>
  </body>
</html>