<?php
	include("functions.php");
	if ($_GET['action']=="studentlogin") {
		$error="";
		if(!$_POST['suname']) {
			$error = "An email address is required.";
		} else if(!$_POST['spsw']) {
			$error = "A password is required.";
		} else if (filter_var($_POST['suname'], FILTER_VALIDATE_EMAIL)==false) {
			$error = "Please enter a valid email address.";
		}
		if($error!="") {	
			echo $error;
			exit();
		}
		$query = "SELECT * FROM students WHERE suname = '".mysqli_real_escape_string($link,$_POST['suname'])."' LIMIT 1";
		$result = mysqli_query($link,$query);
		$row = mysqli_fetch_assoc($result);
		if($row['spsw']==md5(md5($row['sid']).$_POST['spsw'])) {
			echo 1;
			$_SESSION['sid']=$row['sid'];
		} else {	
			$error = "Could not find the username/password combination. Please try again";		
		}
		if($error!="") {	
			echo $error;
			exit();
		}
	}
	if ($_GET['action']=="companylogin") {
		$error="";
		if(!$_POST['cuname']) {
			$error = "An email address is required.";
		} else if(!$_POST['cpsw']) {
			$error = "A password is required.";
		} else if (filter_var($_POST['cuname'], FILTER_VALIDATE_EMAIL)==false) {
			$error = "Please enter a valid email address.";
		}
		if($error!="") {	
			echo $error;
			exit();
		}
		$query = "SELECT * FROM company WHERE cuname = '".mysqli_real_escape_string($link,$_POST['cuname'])."' LIMIT 1";
		$result = mysqli_query($link,$query);
		$row = mysqli_fetch_assoc($result);
		if($row['cpsw']==md5(md5($row['cid']).$_POST['cpsw'])) {
			echo 1;
			$_SESSION['cid']=$row['cid'];
		} else {	
			$error = "Could not find the username/password combination. Please try again";		
		}
		if($error!="") {	
			echo $error;
			exit();
		}
	}
	if ($_GET['action']=="studentregister") {
		$error="";
		if(!$_POST['suname']) {
			$error .= "A username is required.<br>";
		}
		if(!$_POST['spsw']) {
			$error .= "A password is required.<br>";
		}
		if(!$_POST['sname']) {
			$error .= "A name is required.<br>";
		}
		if(!$_POST['sfname']) {
			$error .= "Father's name is required.<br>";
		}
		if(!$_POST['smname']) {
			$error .= "Mother's name is required.<br>";
		}
		if(!$_POST['sgender']) {
			$error .= "A gender is required.<br>";
		}
		if(!$_POST['sbdate']) {
			$error .= "A birth date is required.<br>";
		}
		if(!$_POST['semail']) {
			$error .= "An email address is required.<br>";
		}
		if(!$_POST['sadd']) {
			$error .= "An address is required.<br>";
		}
		if(!$_POST['smob']) {
			$error .= "A mobile number is required.<br>";
		}
		if(!$_POST['sbranch']) {
			$error .= "Branch field is required.<br>";
		}
		if(!$_POST['scoll']) {
			$error .= "College field is required.<br>";
		}
		if(!$_POST['ssem']) {
			$error .= "Semester field is required.<br>";
		}
		if(!$_POST['s10per']) {
			$error .= "10th percentage is required.<br>";
		}
		if(!$_POST['spy10']) {
			$error .= "10th passing year is required.<br>";
		}
		if(!$_POST['s12per']) {
			$error .= "12th percentage is required.<br>";
		}
		if(!$_POST['spy12']) {
			$error .= "12th passing year is required.<br>";
		}
		if(!$_POST['s1yearper']) {
			$error .= "1st year percentage is required.<br>";
		}
		if(!$_POST['s2yearper']) {
			$error .= "2nd year percentage is required.<br>";
		}
		if(!$_POST['s3yearper']) {
			$error .= "3rd year percentage is required.<br>";
		}
		if(!$_POST['s4yearper']) {
			$error .= "4th year percentage is required.<br>";
		}
		if(!$_POST['sbacklog']) {
			$error .= "Backlog field is required.<br>";
		}
		if(!$_POST['scgpa']) {
			$error .= "CGPA field is required.<br>";
		}
		if(!$_POST['sgradyear']) {
			$error .= "Graduation year field is required.<br>";
		}
		if($_POST['suname'] and (filter_var($_POST['suname'], FILTER_VALIDATE_EMAIL)==false)) {
			$error .= "Please enter a valid username.<br>";
		}
		if($_POST['semail'] and (filter_var($_POST['semail'], FILTER_VALIDATE_EMAIL)==false)) {
			$error .= "Please enter a valid email id.<br>";
		}
		if(($_POST['s10per']) and !is_numeric($_POST['s10per'])) {
			$error .= "Your 10th percentage is not numeric.<br>";
		}
		if(($_POST['spy10']) and !is_numeric($_POST['spy10'])) {
			$error .= "Your 10th passing year is not numeric.<br>";
		}
		if(($_POST['s12per']) and !is_numeric($_POST['s12per'])) {
			$error .= "Your 12th percentage is not numeric.<br>";
		}
		if($_POST['spy12'] and !is_numeric($_POST['spy12'])) {
			$error .= "Your 12th passing year is not numeric.<br>";
		}
		if(($_POST['s1yearper']) and !is_numeric($_POST['s1yearper'])) {
			$error .= "Your 1st year percentage is not numeric.<br>";
		}
		if($_POST['s2yearper'] and !is_numeric($_POST['s2yearper'])) {
			$error .= "Your 2nd year percentage is not numeric.<br>";
		}
		if(($_POST['s3yearper']) and !is_numeric($_POST['s3yearper'])) {
			$error .= "Your 3rd year percentage is not numeric.<br>";
		}
		if(($_POST['s4yearper']) and !is_numeric($_POST['s4yearper'])) {
			$error .= "Your 4th year percentage is not numeric.<br>";
		}
		if(($_POST['scgpa']) and !is_numeric($_POST['scgpa'])) {
			$error .= "Your CGPA is not numeric.<br>";
		}
		if($_POST['sgradyear'] and !is_numeric($_POST['sgradyear'])) {
			$error .= "Graduation year field entered is not numeric.<br>";
		}
		if($error!="") {	
			echo $error;
			exit();
		}
		$query = "SELECT * FROM students WHERE suname = '".mysqli_real_escape_string($link,$_POST['suname'])."' LIMIT 1";
		$result = mysqli_query($link,$query);
		if(mysqli_num_rows($result)>0) {
			$error = "That username is already taken";	
		} else {
			$query = "INSERT INTO students(`suname`,`spsw`,`sname`,`sfname`,`smname`,`sgender`,`sbdate`,`semail`,`sadd`,`smob`,`sbranch`,`scoll`,`ssem`,`s10per`,`spy10`,`s12per`,`spy12`,`s1yearper`,`s2yearper`,`s3yearper`,`s4yearper`,`sbacklog`,`scgpa`,`sgradyear`) VALUES ('".mysqli_real_escape_string($link,$_POST['suname'])."','".mysqli_real_escape_string($link,$_POST['spsw'])."','".mysqli_real_escape_string($link,$_POST['sname'])."','".mysqli_real_escape_string($link,$_POST['sfname'])."','".mysqli_real_escape_string($link,$_POST['smname'])."','".mysqli_real_escape_string($link,$_POST['sgender'])."','".mysqli_real_escape_string($link,$_POST['sbdate'])."','".mysqli_real_escape_string($link,$_POST['semail'])."','".mysqli_real_escape_string($link,$_POST['sadd'])."','".mysqli_real_escape_string($link,$_POST['smob'])."','".mysqli_real_escape_string($link,$_POST['sbranch'])."','".mysqli_real_escape_string($link,$_POST['scoll'])."','".mysqli_real_escape_string($link,$_POST['ssem'])."','".mysqli_real_escape_string($link,$_POST['s10per'])."','".mysqli_real_escape_string($link,$_POST['spy10'])."','".mysqli_real_escape_string($link,$_POST['s12per'])."','".mysqli_real_escape_string($link,$_POST['spy12'])."','".mysqli_real_escape_string($link,$_POST['s1yearper'])."','".mysqli_real_escape_string($link,$_POST['s2yearper'])."','".mysqli_real_escape_string($link,$_POST['s3yearper'])."','".mysqli_real_escape_string($link,$_POST['s4yearper'])."','".mysqli_real_escape_string($link,$_POST['sbacklog'])."','".mysqli_real_escape_string($link,$_POST['scgpa'])."','".mysqli_real_escape_string($link,$_POST['sgradyear'])."')";
			if(mysqli_query($link,$query)) {	
				$_SESSION['sid']=mysqli_insert_id($link);
				$query = "UPDATE students SET spsw = '".md5(md5($_SESSION['sid']).$_POST['spsw'])."' WHERE sid = '".$_SESSION['sid']."' LIMIT 1";
				mysqli_query($link,$query);
				echo 1;	
			} else {		
				$error = "Couldn't create the user - please try again later.";		
			}
				
		}
		if($error!="") {	
			echo $error;
			exit();
		}
	}
	if ($_GET['action']=="companyregister") {
		$error="";
		if(!$_POST['cuname']) {
			$error .= "A username is required.<br>";
		}
		if(!$_POST['cname']) {
			$error .= "A company name is required.<br>";
		}
		if(!$_POST['cpsw']) {
			$error .= "A password is required.<br>";
		}
		if(!$_POST['cwebsite']) {
			$error .= "Website field is required.<br>";
		}
		if(!$_POST['cnatureofbusiness']) {
			$error .= "Nature of Business field is required.<br>";
		}
		if(!$_POST['cnamecontact']) {
			$error .= "Contact name is required.<br>";
		}
		if(!$_POST['cdesignation']) {
			$error .= "Designation Field is required.<br>";
		}
		if(!$_POST['ccontactnum']) {
			$error .= "Contact number field is required.<br>";
		}
		if(!$_POST['clandline']) {
			$error .= "Landline number is required.<br>";
		}
		if(!$_POST['cemail']) {
			$error .= "An email is required.<br>";
		}
		if(!$_POST['cfax']) {
			$error .= "Fax field is required.<br>";
		}
		if(!$_POST['cadd']) {
			$error .= "Adress field is required.<br>";
		}
		if(!$_POST['cjobdesoffered']) {
			$error .= "Job designation offered field is required.<br>";
		}
		if(!$_POST['coffer']) {
			$error .= "Types of offer field is required.<br>";
		}
		if(!$_POST['cfax']) {
			$error .= "Fax field is required.<br>";
		}
		if(!$_POST['cadd']) {
			$error .= "Adress field is required.<br>";
		}
		if(!$_POST['cjobdesoffered']) {
			$error .= "Job designation offered field is required.<br>";
		}
		if(!$_POST['coffer']) {
			$error .= "Types of offer field is required.<br>";
		}
		if(!$_POST['cstartup']) {
			$error .= "Startup field is required.<br>";
		}
		if(!$_POST['cnatureofprofile']) {
			$error .= "Nature of Profile field is required.<br>";
		}
		if(!$_POST['coffersmade']) {
			$error .= "Probable no. of offers made field is required.<br>";
		} 
		if(!$_POST['cjobdescription']) {
			$error .= "Job Description offered field is required.<br>";
		}
		if(!$_POST['cmedtest']) {
			$error .= "Medical Test field is not checked.<br>";
		}
		if(!$_POST['cgroupdiscussion']) {
			$error .= "Group Discussion field is not checked.<br>";
		}
		if(!$_POST['cinterview']) {
			$error .= "Interview field is not checked.<br>";
		}
		if(!$_POST['captitudetest']) {
			$error .= "Aptitude Test field is not checked.<br>";
		}
		if(!$_POST['ctechnicaltest']) {
			$error .= "Technical Test field is not checked.<br>";
		}
		if(!$_POST['ctestrequirements']) {
			$error .= "Test requirements field is required.<br>";
		}
		if(!$_POST['cprogram']) {
			$error .= "No Program field is checked.<br>";
		}
		if($_POST['cuname'] and (filter_var($_POST['cuname'], FILTER_VALIDATE_EMAIL)==false)) {
			$error .= "Please enter a valid username.<br>";
		}
		if($_POST['cemail'] and (filter_var($_POST['cemail'], FILTER_VALIDATE_EMAIL)==false)) {
			$error .= "Please enter a valid email id.<br>";
		}
		if($error!="") {	
			echo $error;
			exit();
		}
		$query = "SELECT * FROM company WHERE cuname='".mysqli_real_escape_string($link,$_POST['cuname'])."' LIMIT 1";
		$result = mysqli_query($link,$query);
		if(mysqli_num_rows($result)>0) {
			$error = "That username is already taken";	
		} else {
			$query = "INSERT INTO company(`cuname` , `cname` , `cpsw` , `cwebsite` , `cnatureofbusiness` , `cnamecontact` , `cdesignation` , `ccontactnum` , `clandline` , `cemail` , `cfax` , `cadd` , `cjobdesoffered` , `coffer` , `cstartup` , `cnatureofprofile` , `coffersmade` , `cjobdescription` , `cbonddetails` ,`cmedtest` ,`cgroupdiscussion` ,  `cinterview` , `captitudetest` ,`ctechnicaltest` ,`ctestrequirements` ,`cprogram`) VALUES ('".mysqli_real_escape_string($link,$_POST['cuname'])."','".mysqli_real_escape_string($link,$_POST['cname'])."','".mysqli_real_escape_string($link,$_POST['cpsw'])."','".mysqli_real_escape_string($link,$_POST['cwebsite'])."','".mysqli_real_escape_string($link,$_POST['cnatureofbusiness'])."','".mysqli_real_escape_string($link,$_POST['cnamecontact'])."','".mysqli_real_escape_string($link,$_POST['cdesignation'])."','".mysqli_real_escape_string($link,$_POST['ccontactnum'])."','".mysqli_real_escape_string($link,$_POST['clandline'])."','".mysqli_real_escape_string($link,$_POST['cemail'])."','".mysqli_real_escape_string($link,$_POST['cfax'])."','".mysqli_real_escape_string($link,$_POST['cadd'])."','".mysqli_real_escape_string($link,$_POST['cjobdesoffered'])."','".mysqli_real_escape_string($link,$_POST['coffer'])."','".mysqli_real_escape_string($link,$_POST['cstartup'])."','".mysqli_real_escape_string($link,$_POST['cnatureofprofile'])."','".mysqli_real_escape_string($link,$_POST['coffersmade'])."','".mysqli_real_escape_string($link,$_POST['cjobdescription'])."','".mysqli_real_escape_string($link,$_POST['cbonddetails'])."','".mysqli_real_escape_string($link,$_POST['cmedtest'])."','".mysqli_real_escape_string($link,$_POST['cgroupdiscussion'])."','".mysqli_real_escape_string($link,$_POST['cinterview'])."','".mysqli_real_escape_string($link,$_POST['captitudetest'])."','".mysqli_real_escape_string($link,$_POST['ctechnicaltest'])."','".mysqli_real_escape_string($link,$_POST['ctestrequirements'])."','".mysqli_real_escape_string($link,$_POST['cprogram'])."')";
			if(mysqli_query($link,$query)) {	
				$_SESSION['cid']=mysqli_insert_id($link);
				$query = "UPDATE company SET cpsw = '".md5(md5($_SESSION['cid']).$_POST['cpsw'])."' WHERE cid = '".$_SESSION['cid']."' LIMIT 1";
				mysqli_query($link,$query);
				echo 1;	
			} else {		
				$error = "Couldn't create the user - please try again later.";		
			}
				
		}
		if($error!="") {	
			echo $error;
			exit();
		}
	}
	
	if ($_GET['action']=="adminlogin") {
		$error="";
		if(!$_POST['auname']) {
			$error = "An email address is required.";
		} else if(!$_POST['apsw']) {
			$error = "A password is required.";
		} else if (filter_var($_POST['auname'], FILTER_VALIDATE_EMAIL)==false) {
			$error = "Please enter a valid email address.";
		}
		if($error!="") {	
			echo $error;
			exit();
		}
		$query = "SELECT * FROM admin WHERE auname = '".mysqli_real_escape_string($link,$_POST['auname'])."' LIMIT 1";
		$result = mysqli_query($link,$query);
		$row = mysqli_fetch_assoc($result);
		if($row['apsw']==$_POST['apsw']) {
			echo 1;
			$_SESSION['aid']=$row['aid'];
		} else {	
			$error = "Could not find the username/password combination. Please try again";		
		}
		if($error!="") {	
			echo $error;
			exit();
		}
	}
	
	
	if ($_GET['action']=="addannouncements") {
		$uploadDir = 'uploads/'; 
		$response = array( 
		'status' => 0, 
		'message' => 'Form submission failed, please try again.' 
		); 
		if(isset($_POST['antitle']) || isset($_POST['andes']) || isset($_POST['anfile'])){ 
		$title = $_POST['antitle']; 
		$description = $_POST['andes'];
		if(!empty($title) && !empty($description)){ 
            $uploadStatus = 1; 
            $uploadedFile = ''; 
            if(!empty($_FILES["file"]["name"])){ 
                $fileName = basename($_FILES["file"]["name"]); 
                $targetFilePath = $uploadDir . $fileName; 
                $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);                    
                if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){ 
                    $uploadedFile = $fileName; 
                }else{ 
                    $uploadStatus = 0; 
                    $response['message'] = 'Sorry, there was an error uploading your file.'; 
                } 
            } 
            if($uploadStatus == 1){
                $query="INSERT INTO announcements (antitle,andes,anfile) VALUES ('".$title."','".$description."','".$uploadedFile."')"; 
                $result = mysqli_query($link,$query);
                if($result){ 
                    $response['status'] = 1; 
                    $response['message'] = 'Form data submitted successfully!'; 
                } 
            }  
			}else{ 
				$response['message'] = 'Please fill all the mandatory fields (title and description).'; 
			} 
		} 
		echo json_encode($response);
	}
	
	
	
	if ($_GET['action']=="companySchedule") {
		$error="";
		if(!$_POST['schcname']) {
			$error .= "A company name is required.<br>";
		}
		if(!$_POST['schdate']) {
			$error .= "A date is required.<br>";
		}
		if(!$_POST['schinterview']) {
			$error .= "An interview time is required.<br>";
		}
		if(!$_POST['schbacklog']) {
			$error .= "Backlog field is required.<br>";
		}
		if(!$_POST['schplacement']) {
			$error .= "Placement type field is required.<br>";
		}
		if(!$_POST['schprogram']) {
			$error .= "No program field is checked.<br>";
		}
		if(!$_POST['schminper']) {
			$error .= "Minimum Percentage field is required.<br>";
		}
		if($error!="") {	
			echo $error;
			exit();
		}
		$query = "INSERT INTO companyschedule(`schcname` , `schdate` , `schinterview` , `schbacklog` , `schplacement` , `schprogram` , `schminper`) VALUES ('".mysqli_real_escape_string($link,$_POST['schcname'])."','".mysqli_real_escape_string($link,$_POST['schdate'])."','".mysqli_real_escape_string($link,$_POST['schinterview'])."','".mysqli_real_escape_string($link,$_POST['schbacklog'])."','".mysqli_real_escape_string($link,$_POST['schplacement'])."','".mysqli_real_escape_string($link,$_POST['schprogram'])."','".mysqli_real_escape_string($link,$_POST['schminper'])."')";
		if(mysqli_query($link,$query)) {	
				echo 1;	
		} else {		
			$error = "Some error happened. Please try again later.";		
		}
		if($error!="") {	
			echo $error;
			exit();
		}
	}
?>